package Nephia::Response;
use strict;
use warnings;
use parent 'Plack::Response';

1;

__END__
