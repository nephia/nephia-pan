# NAME

Nephia::Setup::Plugin::Assets::JQuery -  Download and deploy jQuery into your webapp

# SYNOPSIS

    $ nephia-setup YourApp --plugins Assets::JQuery

# DESCRIPTION

Nephia::Setup::Plugin::Assets::JQuery is downloader for Nephia::Setup that is downloads jQuery.

# LICENSE

Copyright (C) ytnobody.

This library is free software; you can redistribute it and/or modify
it under the same terms as Perl itself.

# AUTHOR

ytnobody <ytnobody@gmail.com>
