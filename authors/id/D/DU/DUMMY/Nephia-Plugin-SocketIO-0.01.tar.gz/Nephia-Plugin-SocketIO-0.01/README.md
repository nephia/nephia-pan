# NAME

Nephia::Plugin::SocketIO - It's new $module

# SYNOPSIS

    use Nephia::Plugin::SocketIO;

# DESCRIPTION

Nephia::Plugin::SocketIO is ...

# LICENSE

Copyright (C) ytnobody.

This library is free software; you can redistribute it and/or modify
it under the same terms as Perl itself.

# AUTHOR

ytnobody <ytnobody@gmail.com>
